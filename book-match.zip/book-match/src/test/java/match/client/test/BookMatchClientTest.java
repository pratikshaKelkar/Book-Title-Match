package match.client.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.BDDMockito.Then;
import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import match.client.BookMatchClient;
import match.client.BooksToMatch;
import match.dao.BookDao;
import match.dao.BookDaoImpl;
import match.model.Book;
import match.client.BooksToMatch;

@RunWith(PowerMockRunner.class)
@PrepareForTest(BookMatchClient.class)
@PowerMockIgnore("javax.management.*")
public class BookMatchClientTest {
	@Mock
	BookDao bookDaoImpl;

	@InjectMocks
	BookMatchClient bookMatchClient = new BookMatchClient();;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void matchBookTitleTest() {
		
		List<Book> bookList = new ArrayList<Book>();
		Book book1=new Book();
		book1.setBookTitle("Shoulder Arthroplasty");
		Book book2=new Book();
		book2.setBookTitle("Head and Neck Imaging");
		Book book3=new Book();
		book3.setBookTitle("Shackelford''s Surgery of the Alimentary Tract");
		Book book4=new Book();
		book4.setBookTitle("Aids Therapy");
		Book book5=new Book();
		book5.setBookTitle("Andrews Diseases Skin Clinical Dermatology");
		
		bookList.add(book1);
		bookList.add(book2);
		bookList.add(book3);
		bookList.add(book4);
		bookList.add(book5);
		
		
		when(bookDaoImpl.fetchBookList()).thenReturn(bookList);

		Map<String, Boolean> bookTitleMap = bookMatchClient.matchBookTitle();

		assertEquals(bookTitleMap.size(), 4);

	}
//negatve scenarios
	@Test
	public void matchBookTitleTest2() {
		
		List<Book> bookList = new ArrayList<Book>();
		Book book1=new Book();
		book1.setBookTitle("Shoulder Arthroplasty");
		Book book2=new Book();
		book2.setBookTitle("Head and Neck Imaging");
		Book book3=new Book();
		book3.setBookTitle("Shackelford''s Surgery of the Alimentary Tract");
		Book book4=new Book();
		book4.setBookTitle("Aids Therapy");
		Book book5=new Book();
		book5.setBookTitle("Andrews Diseases Skin Clinical Dermatology");
		
		bookList.add(book1);
		bookList.add(book2);
		bookList.add(book3);
		bookList.add(book4);
		bookList.add(book5);
		
		when(bookDaoImpl.fetchBookList()).thenReturn(bookList);

		Map<String, Boolean> bookTitleMap = bookMatchClient.matchBookTitle();

		assertEquals(bookTitleMap.size(), 4);

	}
}