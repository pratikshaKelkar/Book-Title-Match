package match.client;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import match.dao.BookDao;

import match.model.Book;

/**
 * @author PratikshaK class compares book titles from a client application to
 *         book titles stored in a database and returns true of false if titles
 *         match.
 */
@Component
public final class BookMatchClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookMatchClient.class);
	@Autowired
	private BookDao bookDaoImpl;

	public static void main(String[] args) {
		BookMatchClient bookMatchClient = startFramework();
		bookMatchClient.matchBookTitle();
	}
	static BookMatchClient startFramework() {
		ApplicationContext ac = new ClassPathXmlApplicationContext("/applicationContext.xml");
		return ac.getBean(BookMatchClient.class);
	}
	/**
	 *  after checking following conditions : 
	 * 
	 * Capitalization should be ignored
	 * Punctuation and whitespace should be ignored
	 * These noise words should be ignored: the
 		* in
 		* of
 		* and
 		* @return a result
 	 */
	public Map<String, Boolean> matchBookTitle() {
		List<Book> bookList = bookDaoImpl.fetchBookList();

		Map<String, Boolean> bookTitleMap = new HashMap<String, Boolean>();

		String[] matches = new String[] { "the", "in", "of", "and" };
		String inputTitle;

		for (BooksToMatch bookTitle : BooksToMatch.values()) {
			inputTitle = bookTitle.getTitle().replaceAll("\\s+", " ");

			String[] splittedInputBookName = inputTitle.split("\\s+");
			for (String inputStringwords : splittedInputBookName) {
				for (String word : matches) {
					if (inputStringwords.equalsIgnoreCase(word)) {
						inputTitle = inputTitle.replaceAll(word, "");
					}
				}
			}

			// removed punctuation and whitespace 
			String inputStringPunctuated = inputTitle.replaceAll("[^a-zA-Z]", "");
			for (Book book : bookList) {
				String bookName = book.getBookTitle();
				
				compareTitles(bookName, matches);
				// removed punctuation and whitespace 
				String punctuatedBookTitlefromDb = bookName.replaceAll("[^a-zA-Z]", "");

				if (inputStringPunctuated.equalsIgnoreCase(punctuatedBookTitlefromDb)) {
					bookTitleMap.put(inputTitle + ": Exists --> ", true);
					break;
				} else {
					bookTitleMap.put(inputTitle + ": Exists --> ", false);
				}
			}
		}
		for (Map.Entry<String, Boolean> entry : bookTitleMap.entrySet()) {
			LOGGER.info("{}{} ", entry.getKey(), entry.getValue());
		}
		return bookTitleMap;
	}
	public void compareTitles(String bookName,String[] matches ){
		String[] splitteddbBookName = bookName.split("\\s+");
		for (String dbString : splitteddbBookName) {
			for (String word : matches) {
				if (dbString.equalsIgnoreCase(word)) {
					bookName = bookName.replaceAll(word, "");
					
				}
			}
		}
	}
}
