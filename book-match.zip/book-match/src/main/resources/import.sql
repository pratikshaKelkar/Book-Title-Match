INSERT INTO books (id, book_title, book_author) VALUES (1, 'Shoulder Arthroplasty', 'Gary M. Gartsman, and T. Bradley Edwards');
INSERT INTO books (id, book_title, book_author) VALUES (2, 'Head and Neck Imaging', null);
INSERT INTO books (id, book_title, book_author) VALUES (3, 'Shackelford''s Surgery of the Alimentary Tract', 'Charles J. Yeo');
INSERT INTO books (id, book_title, book_author) VALUES (4, '	Aids   Therapy', 'Raphael Dolin, Henry Masur, and Michael Saag');
INSERT INTO books (id, book_title, book_author) VALUES (5, 'Andrews Diseases Skin Clinical Dermatology', 'William D James, Timothy G Berger, and Dirk M Elston');
